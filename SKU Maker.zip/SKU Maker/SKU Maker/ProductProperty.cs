﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace SKU_Maker
{
    [XmlRoot("Property")]
    public class ProductProperty
    {
        [XmlAttribute("title")]
        public string Title { get; set; }
        public List<PropertyOption> Values { get; set; }

        public ProductProperty()
        {
        }

        public ProductProperty(string title)
        {
            Title = title;
            Values = new List<PropertyOption>();
        }

        public void AddValidValue(string value, string code)
        {
            Values.Add(PropertyOption.Create(value, code));
        }
    }

    [XmlRoot("Valid Property Option")]
    public class PropertyOption
    {
        [XmlAttribute("name")]
        public string Name { get; set; }
        [XmlAttribute("code")]
        public string Code { get; set; }

        public static PropertyOption Create(string name, string code)
        {
            PropertyOption prop = new PropertyOption();
            prop.set(name, code);
            return prop;
        }

        public PropertyOption()
        {
        }

        public void set(string name, string code)
        {
            Name = name;
            Code = code;
        }
    }
}
