﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace SKU_Maker
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Product product = new Product("Wall");
            //ProductProperty colors = new ProductProperty("Color");
            //colors.AddValidValue("White", "W");
            //colors.AddValidValue("Brushed Nickel", "BN");
            //ProductProperty pattern = new ProductProperty("Pattern");
            //pattern.AddValidValue("Othello", "OTH");
            //pattern.AddValidValue("BasketVille", "BV");
            //pattern.AddValidValue("Some Pattern", "SM");
            //pattern.AddValidValue("New XML", "NX");

            //product.Properties.Add(colors);
            //product.Properties.Add(pattern);

            //product.Save("product.xml");


            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());

            Product prod = Product.Load("product.xml");
            MessageBox.Show("done!", "another one");
        }
    }
}
