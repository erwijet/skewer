﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace SKU_Maker
{
    public partial class Form1 : Form
    {
        public List<Product> Products { get; set; }

        public Form1()
        {
            InitializeComponent();

            Products = new List<Product>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #region Product Buttons

        private void btn_prod_add_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "XML Files|*.xml";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        Product p = Product.Load(ofd.FileName);
                        Products.Add(p);
                        cbl_products.Items.Add(p.Name);
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Error in loading XML File. Double check the XML is correct. Was this generated with Skewer?", "IO Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btn_prod_remove_Click(object sender, EventArgs e)
        {
            Products.RemoveAt(cbl_products.SelectedIndex);
            cbl_products.Items.RemoveAt(cbl_products.SelectedIndex);
        }

        private void btn_prod_create_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "XML Files|*.xml";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    Product product = new Product("Untitled Product");
                    Form frm = new frm_edit_xml(product, sfd.FileName);
                    frm.ShowDialog();
                }
            }
        }

        private void btn_prod_modify_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "XML Files|*.xml";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    Product product = Product.Load(ofd.FileName);
                    Form editForm = new frm_edit_xml(product, ofd.FileName);
                    editForm.ShowDialog();
                }
            }
        }

        #endregion

        private void cbl_products_SelectedIndexChanged(object sender, EventArgs e)
        {
            btn_prod_remove.Enabled = cbl_products.SelectedItem != null;
        }

        private void tp_sku_Click(object sender, EventArgs e)
        {

        }
    }
}
