﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Xml.Serialization;

namespace SKU_Maker
{
    [XmlRoot("Product")]
    public class Product
    {
        [XmlAttribute("title")]
        public string Name { get; set; }
        public List<ProductProperty> Properties { get; set; }

        public Product()
        {
        }

        public Product(string name)
        {
            Name = name;
            Properties = new List<ProductProperty>();
        }

        public void Save(string filename)
        {
            StreamWriter writer = new StreamWriter(filename);
            XmlSerializer serializer = new XmlSerializer(typeof(Product));
            serializer.Serialize(writer, this);
            writer.Close();
        }

        public static Product Load(string filename)
        {
            StreamReader reader = new StreamReader(filename);
            XmlSerializer serializer = new XmlSerializer(typeof(Product));
            return serializer.Deserialize(reader) as Product;
        }
    }
}
